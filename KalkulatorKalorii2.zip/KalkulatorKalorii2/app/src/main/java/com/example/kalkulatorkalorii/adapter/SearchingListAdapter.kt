package com.example.kalkulatorkalorii.adapter

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.example.kalkulatorkalorii.R

class SearchingListAdapter(val items: List<ItemResult?>?, val context: Context, val fragment: Fragment) : RecyclerView.Adapter<SearchingListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val v: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.data_in_search,parent,false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = items!![position]!!
        holder.title.text = item.title

        holder.addButton.setOnClickListener{
            Thread{
                val db = ItemsDB.getInstance(context)
                val itemInsert = Item()
                itemInsert.title = item.title!!
                itemInsert.kcal = item.kcal!!
                itemInsert.fat = item.fat!!
                itemInsert.proteins = item.proteins!!
                itemInsert.carbo = item.carbo!!
                db.itemDao().insert(itemInsert)
            }.start()
            Toast.makeText(context, "Item added", Toast.LENGTH_SHORT).show()
        }

        holder.singleItem.setOnClickListener {
            val intent = Intent(context, DisplayItem::class.java).apply {
                putExtra("title", item.title)
                putExtra("kcal", item.kcal)
                putExtra("fat", item.fat)
                putExtra("proteins", item.proteins)
                putExtra("carbo", item.carbo)
            }
            (context as MainActivity).startActivity(intent)
        }
    }


    class ViewHolder(itemView:View): RecyclerView.ViewHolder(itemView){
        val title = itemView.findViewById<TextView>(R.id.iitem_title)
        val addButton = itemView.findViewById<Button>(R.id.add_item)
        val singleItem = itemView.findViewById<LinearLayout>(R.id.singe_item)
    }

    override fun getItemCount(): Int {
        return if (items == null) 0 else items.size
    }
    }