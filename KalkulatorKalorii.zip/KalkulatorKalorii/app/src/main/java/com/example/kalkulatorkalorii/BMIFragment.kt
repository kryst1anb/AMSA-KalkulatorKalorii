package com.example.kalkulatorkalorii

class BMIFragment {
}