package com.example.kalkulatorkalorii

class ItemsFragment {
}