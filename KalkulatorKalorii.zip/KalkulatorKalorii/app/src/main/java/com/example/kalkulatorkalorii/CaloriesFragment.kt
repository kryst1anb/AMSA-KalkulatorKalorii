package com.example.kalkulatorkalorii

class CaloriesFragment {
}