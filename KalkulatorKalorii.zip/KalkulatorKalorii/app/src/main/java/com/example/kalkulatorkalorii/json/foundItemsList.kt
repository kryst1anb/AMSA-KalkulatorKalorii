package com.example.kalkulatorkalorii.json

import androidx.lifecycle.LiveData
import com.google.gson.annotations.SerializedName

class foundItemsList {
    @SerializedName("results")
    var itemList: LiveData<List<foundItem>>? = null
}