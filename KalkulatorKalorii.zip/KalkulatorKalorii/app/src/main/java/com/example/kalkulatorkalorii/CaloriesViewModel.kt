package com.example.kalkulatorkalorii

class CaloriesViewModel {
}