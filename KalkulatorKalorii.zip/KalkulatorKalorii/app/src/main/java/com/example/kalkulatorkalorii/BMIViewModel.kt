package com.example.kalkulatorkalorii

class BMIViewModel {
}