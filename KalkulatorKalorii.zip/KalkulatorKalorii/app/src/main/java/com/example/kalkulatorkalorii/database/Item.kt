package com.example.kalkulatorkalorii.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "items_table")
data class Item {
    @PrimaryKey(autoGenerate = true)
    var id: Int? = 0,

    @ColumnInfo(name = "item_name")
    var title: String="n",

    @ColumnInfo(name = "item_kcal")
    var kcal: Int = 0,

    @ColumnInfo(name = "item_fat")
    var fat: Int = 0,

    @ColumnInfo(name = "item_carbohydrates")
    var carbohydrates: Int = 0,

    @ColumnInfo(name = "item_protein")
    var protein: Int = 0,
}