package com.example.kalkulatorkalorii

class BMRFragment {
}