package com.example.kalkulatorkalorii.searching

import android.telecom.Call
import android.util.Log
import com.google.gson.Gson
import okhttp3.*
import java.io.IOException
import androidx.lifecycle.ViewModel
import com.example.kalkulatorkalorii.json.serialized
import javax.security.auth.callback.Callback


class searchingViewModel : ViewModel() {


    fun apiConnect (typedSearch: String){

        var searchTable = typedSearch.split(" ".toRegex())

        var url = "https://nutritionix-api.p.rapidapi.com"
        for(i in 0 until searchTable.size-1)
            url += searchTable[i] + "%20"
        url += searchTable[searchTable.size-1]

        try{
            val client = OkHttpClient()
            val request = Request.Builder()
                .url(url)
                .get()
                .addHeader("x-rapidapi-host", "nutritionix-api.p.rapidapi.com")
                .addHeader("x-rapidapi-key", "375c5ab2fcmsh7b1007a6516e98ep10931fjsn19eabd2048af")
                .build()

            client.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException?){
                    call.cancel()
                    Log.e("Failed: ", e.toString())
                }

                @Throws(IOException::class)
                override fun onResponse(call: Call?, response: Response) {
                    val myResponse = response.body().toString()
                    var gson = Gson()
                    val data = gson.fromJson(myResponse, serialized::class.java)
                    //searchedRecipesList = data
                }

            })
        }
    }

}