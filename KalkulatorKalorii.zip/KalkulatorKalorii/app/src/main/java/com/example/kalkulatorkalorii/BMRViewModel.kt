package com.example.kalkulatorkalorii

class BMRViewModel {
}