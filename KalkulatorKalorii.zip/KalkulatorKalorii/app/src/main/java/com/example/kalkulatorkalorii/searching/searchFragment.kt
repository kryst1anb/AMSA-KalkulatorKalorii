package com.example.kalkulatorkalorii.searching

class searchFragment {
}